<?php

namespace App\Constants;

class Pagination
{
    const PerPage = 16;
}
